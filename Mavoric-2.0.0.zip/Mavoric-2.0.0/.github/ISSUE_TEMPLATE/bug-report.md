---
name: Bug report
about: Something's not working properly or another issue is causing the plugin to
  be inadequate. We usually respond to these issues within a few hours.
title: "[BUG] "
labels: Bug
assignees: Olybear9

---

<!-- A clear and concise description of what the bug is. -->
## Description
This bug allows you to spin, and is really annoying. And it occurs when you type "/bug-report-test-command" in game.

**Additional context**
Add any other context about the problem here.
