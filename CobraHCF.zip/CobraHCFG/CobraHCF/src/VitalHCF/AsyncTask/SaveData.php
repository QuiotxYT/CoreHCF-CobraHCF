<?php

namespace VitalHCF\AsyncTask;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\item\Items;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;

class SaveData extends AsyncTask {
	
	/** @var AsyncTask */
	protected $name, $items, $armorItems, $config;
	
	/**
	 * SaveData Constructor.
	 * @param String $name
	 * @param Array $items
	 * @param Array $armorItems
	 * @param Config $config
	 */
	public function __construct($name, $items, $armorItems, $config){
		$this->name = $name;
		$this->items = $items;
		$this->armorItems = $armorItems;
		$this->config = $config;
	}
	
	/**
	 * @return void
	 */
	public function onRun() : void {
		$fileData = [];
		$file = $this->config;
		foreach($this->items as $slot => $item){
			$fileData["items"][$slot] = Items::itemSerialize($item);
		}
		foreach($this->armorItems as $slot => $item){
			$fileData["armorItems"][$slot] = Items::itemSerialize($item);
		}
		$file->set($this->name, $fileData);
		$file->save();
	}
}

?>