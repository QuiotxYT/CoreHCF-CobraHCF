<?php

namespace VitalHCF\Task;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\listeners\event\{SOTW, EOTW};

use pocketmine\scheduler\Task;
use pocketmine\utils\{Config, TextFormat as TE};

class Scoreboard extends Task {

    /** @var Player */
    protected $player;

    /**
     * Scoreboard Constructor.
     * @param Loader $plugin
     */
    public function __construct(Player $player){
        $this->player = $player;
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        	return;
        }
        $config = Loader::getConfiguration("scoreboard_settings");
        $api = Loader::getScoreboard();
        /** @var array */
        $scoreboard = [];
        if($player->isCombatTag()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getCombatTagTime())], $config->get("CombatTag"));
        }
        if($player->isTeleportingHome()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getTeleportingHomeTime())], $config->get("Home"));
        }
        if($player->isTeleportingStuck()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getTeleportingStuckTime())], $config->get("Stuck"));
        }
        if($player->isLogout()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getLogoutTime())], $config->get("Logout"));
        }
        if($player->isGoldenGapple()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getGoldenAppleTime())], $config->get("Apple"));
        }
        if($player->isEnderPearl()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getEnderPearlTime())], $config->get("EnderPearl"));
        }
        if(SOTW::isEnable()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToFullString(SOTW::getTime())], $config->get("SOTW"));
        }
        if(EOTW::isEnable()){
            $scoreboard[] = str_replace(["&", "{time}"], ["§", Loader::getTimeToFullString(EOTW::getTime())], $config->get("EOTW"));
        }
        if(SOTW::getTime() === 0){
            if($player->isStormBreaker()){
                $scoreboard[] = "§dPartner items: ";
            }
            if($player->isAntiTrapper()){
                $scoreboard[] = "§dPartner items: ";
            }
            if($player->isSnowball()){
                $scoreboard[] = "§dPartner items: ";
            }
        }
        if($player->isStormBreaker()){
            $scoreboard[] = " " . str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getStormBreakerTime())], $config->get("StormBreaker"));
        }
        if($player->isAntiTrapper()){
            $scoreboard[] = " " . str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getAntiTrapperTime())], $config->get("AntiTrapper"));
        }
        if($player->isSnowball()){
            $scoreboard[] = " " . str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getSnowballTime())], $config->get("Snowball"));
        }
        if($player->isBardClass()){
            $scoreboard[] = str_replace(["&", "{bardEnergy}"], ["§", $player->getBardEnergy()], $config->get("BardEnergy"));
        }
        if($player->isArcherClass()){
            $scoreboard[] = str_replace(["&", "{archerEnergy}"], ["§", $player->getArcherEnergy()], $config->get("ArcherEnergy"));
        }
        if(count($scoreboard) >= 1){
            $scoreboard[] = TE::GRAY."                    ";
            $texting = [TE::GRAY.TE::GRAY."                    "];
      	  $scoreboard = array_merge($texting, $scoreboard);
        }else{
        	$api->removePrimary($player);
        	return;
        }
        $api->newScoreboard($player, $player->getName(), str_replace(["&"], ["§"], $config->get("scoreboard_name")));
        if($api->getObjectiveName($player) !== null){
            foreach($scoreboard as $line => $key){
                $api->remove($player, $scoreboard);
                $api->newScoreboard($player, $player->getName(), str_replace(["&"], ["§"], $config->get("scoreboard_name")));
            }
        }
        foreach($scoreboard as $line => $key){
            $api->setLine($player, $line + 1, $key);
        }
    }
}

?>