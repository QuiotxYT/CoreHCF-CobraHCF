<?php

namespace VitalHCF\entities\tiles;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\block\MonsterSpawner;

use pocketmine\tile\Spawnable;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\level\Level;

use pocketmine\block\{Block, Air};
use pocketmine\item\{Item, ItemIds};

use pocketmine\nbt\tag\{CompoundTag, StringTag, IntTag, ShortTag, ListTag};

class MonsterTileSpawner extends Spawnable {
	
	const ENTITY_NAME_KEY = "Spawner_Name";
	
	/** @var Int */
	protected $spawnDelay = 0;
	
	/** @var String */
	protected $spawnerName = "";
	
	/**
	 * MonsterTileSpawner
	 * @param Level $level
	 * @param CompoundTag $nbt
	 */
	public function __construct(Level $level, CompoundTag $nbt){
		parent::__construct($level, $nbt);
		$this->scheduleUpdate();
	}
	
	/**
	 * @return bool
	 */
	public function onUpdate() : bool {
		if($this->closed){
			return false;
		}
		if(!$this->getLevel()->getBlock($this) instanceof MonsterSpawner){
			$this->close();
			return false;
		}
		$success = false;
		--$this->spawnDelay;
		if($this->spawnDelay <= 0 && $this->canUpdate()){
			$position = $this->add(rand(1, 5), rand(-1, 1), rand(1, 5));
    		$entity = Entity::createEntity($this->getNameNBT(), $this->getLevel(), Entity::createBaseNBT($position->add(2, 2, 2), null, 0, 0));
    		if($entity instanceof Entity){
    			$success = true;
    			$entity->spawnToAll();
   	 	}
   	 	if($success){
    			$this->spawnDelay = Loader::getDefaultConfig("LevelManager")["EntitySpawnDelay"];
    		}
    	}
        return true;
	}
	
	/**
	 * @return bool
	 */
	public function canUpdate() : bool {
		if($this->getLevel()->isChunkLoaded($this->getX() >> 4, $this->getZ() >> 4)){
			$hasUpdate = false;
			foreach($this->getLevel()->getEntities() as $player){
				if($player instanceof Player && (int)$player->distance($this) <= 16){
					$hasUpdate = true;
				}
			}
			return $hasUpdate;
		}
		return $hasUpdate;
	}
	
	/**
     * @param CompoundTag $nbt
     */
    public function addAdditionalSpawnData(CompoundTag $nbt): void {
        $nbt->setString(self::ENTITY_NAME_KEY, $this->getNameNBT());
        $this->scheduleUpdate();
    }

    /**
     * @param CompoundTag $nbt
     */
    public function readSaveData(CompoundTag $nbt): void {
        if($nbt->hasTag(self::ENTITY_NAME_KEY)){
        	$this->setNameNBT($nbt->getString(self::ENTITY_NAME_KEY));
        }
    }

    /**
     * @param CompoundTag $nbt
     */
    public function writeSaveData(CompoundTag $nbt): void {
        $this->addAdditionalSpawnData($nbt);
    }
    
    /**
     * @param String $name
     */
    public function setNameNBT(String $name){
    	$this->spawnerName = $name;
    }
    
    /**
     * @return String
     */
    public function getNameNBT() : String {
    	return $this->spawnerName;
    }
}

?>