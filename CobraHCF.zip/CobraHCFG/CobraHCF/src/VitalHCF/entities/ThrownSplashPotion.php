<?php

namespace VitalHCF\entities;

use VitalHCF\player\Player;
use VitalHCF\API\projectile\Throwable;

use pocketmine\item\Potion;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\utils\Color;

use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\nbt\tag\{CompoundTag, ShortTag};

class ThrownSplashPotion extends Throwable {
	
	/** @var Int */
	const NETWORK_ID = 86;

	/** @var float */
    public $width = 0.25, $length = 0.25, $height = 0.25;

	/** @var float */
    protected $gravity = 0.1, $drag = 0.05;
    
    /** @var bool */
    private $hasSplashed = false;
    
    /**
     * ThrownSplashPotion Constructor.
     * @param Level $level
     * @param CompoundTag $nbt
     * @param Entity $entity
     */
    public function __construct(Level $level, CompoundTag $nbt, Entity $entity){
    	parent::__construct($level, $nbt, $entity);
    }
    
    /**
     * @return Int
     */
    public function getPotionId() : Int {
    	return (int)$this->namedtag["PotionId"];
   }
   
   /**
    * @return void
    */
   public function splashPotion() : void {
   	if(!$this->hasSplashed){
   		$this->hasSplashed = true;
   		$radius = 6;
   		$colors = [new Color(0x38, 0x5d, 0xc6)];
   
   		$this->level->broadcastLevelEvent($this, LevelEventPacket::EVENT_PARTICLE_SPLASH, Color::mix(...$colors)->toARGB());
		   $this->level->broadcastLevelSoundEvent($this, LevelSoundEventPacket::SOUND_GLASS);
   		foreach($this->getLevel()->getNearbyEntities($this->getBoundingBox()->expand($radius, $radius, $radius)) as $entity){
   			foreach(Potion::getPotionEffectsById($this->getPotionId()) as $effect){
   				if($entity instanceof Player){
   					$entity->addEffect($effect);
   				}
   			}
   		}
   		$this->close();
   	}
   }
   
   /** 
	 * @param Int $currentTick
	 * @return bool
	 */
	public function onUpdate(Int $currentTick) : bool {
		if($this->closed){
			return false;
		}
		$this->timings->startTiming();
		$hasUpdate = parent::onUpdate($currentTick);
		
		if($this->isCollided){
			$this->splashPotion();
			$hasUpdate = true;
		}
		$this->timings->stopTiming();
		return $hasUpdate;
    }
}

?>