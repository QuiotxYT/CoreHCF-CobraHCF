<?php

namespace VitalHCF\listeners\block;

use VitalHCF\{Loader, Factions};

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;

use pocketmine\block\{Door, Fence, FenceGate, Trapdoor, Chest, TrappedChest};
use pocketmine\item\{Bucket, Hoe, Shovel};

class BlockBreak implements Listener {
	
	/** @var Loader */
    protected $plugin;

    /**
     * BlockBreak Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @paran BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreak(BlockBreakEvent $event) : void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        if($player->isGodMode()) return;
        if(Factions::isSpawnRegion($block)||Factions::isProtectedRegion($block)){
        	$event->setCancelled(true);
        }
        if($event->isCancelled()) return;
        foreach($event->getDrops() as $drop){
            $player->getInventory()->addItem($drop);
        }
        $event->setDrops([]);
    }
}

?>