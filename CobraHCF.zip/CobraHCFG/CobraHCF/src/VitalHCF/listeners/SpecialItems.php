<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;
use VitalHCF\Task\specials\{StormBreakerTask, AntiTrapperTask, SnowballTask};
use VitalHCF\item\specials\{StormBreaker, AntiTrapper, NinjaShear};

use pocketmine\utils\TextFormat as TE;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\block\{Fence, FenceGate};

use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent, ProjectileHitEvent, ProjectileHitEntityEvent};
use pocketmine\event\player\PlayerInteractEvent;

use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};

use pocketmine\entity\projectile\Snowball;
use pocketmine\entity\projectile\Egg;
use pocketmine\entity\{Effect, EffectInstance};

class SpecialItems implements Listener {

    /** @var Loader */
    protected $plugin;

    /** @var array */
	protected $projectile = [];

    /**
     * SpecialItems Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function onEntityDamageEvent(EntityDamageEvent $event) : void {
        $player = $event->getEntity();
        if($event instanceof EntityDamageByEntityEvent){
            $damager = $event->getDamager();
            if($event->getCause() === EntityDamageEvent::CAUSE_ENTITY_ATTACK||$event->getCause() === EntityDamageEvent::CAUSE_PROJECTILE){
				if($player instanceof Player && $damager instanceof Player){
	                $item = $damager->getInventory()->getItemInHand();
	                if($item instanceof StormBreaker){
	                    if(Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;
	                    //TODO:
	                    if($damager->isStormBreaker()){
	                        $damager->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($damager->getStormBreakerTime())], Loader::getConfiguration("messages")->get("stormbreaker_cooldown")));
	                        $event->setCancelled(true);
	                        return;
	                    }
	                    $helmet = $player->getArmorInventory()->getHelmet();
	                    if($helmet !== null){
	                        $itemRemove = $player->getInventory()->getItemInHand();
	                        if($itemRemove !== null){
	                            $player->getArmorInventory()->setHelmet($itemRemove);
	                            $player->getInventory()->setItemInHand($helmet);
	                        }
	                    }
	                    $item->reduceUses($damager);
	                    $damager->setStormBreaker(true);
	                    $this->plugin->getScheduler()->scheduleRepeatingTask(new StormBreakerTask($damager), 20);
	                }
	                if($item instanceof AntiTrapper){
	                    if(Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;
	                    //TODO:
	                    if($damager->isAntiTrapper()){
	                        $damager->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($damager->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_cooldown")));
	                        $event->setCancelled(true);
	                        return;
	                    }
	                    $item->reduceUses($damager);
	                    $damager->setAntiTrapper(true);
	                    //TODO: here we place the time for which the player cannot place blocks
	                    $player->setAntiTrapperTarget(true);
	                    $this->plugin->getScheduler()->scheduleRepeatingTask(new AntiTrapperTask($damager, $player), 20);
	                }
	            }
	        }
	    }
	}
	
    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreak(BlockBreakEvent $event) : void {
        $player = $event->getPlayer();
        if($player->isAntiTrapperTarget()){
            //TODO:
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->setCancelled(true);
        }
    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onBlockPlace(BlockPlaceEvent $event) : void {
        $player = $event->getPlayer();
        if($player->isAntiTrapperTarget()){
            //TODO:
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->setCancelled(true);
        }
    }

    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $event->getItem();
        if($player->isAntiTrapperTarget()){
            //TODO:
            if($block instanceof Fence||$block instanceof FenceGate){
                $player->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
                $event->setCancelled(true);
            }
        }
        if($item instanceof \pocketmine\item\Snowball && $player->getInventory()->getItemInHand()->getCustomName() === TE::GOLD."SnowBall"){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
                if($player->isSnowball()){
                    $player->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getSnowballTime())], Loader::getConfiguration("messages")->get("snowball_cooldown")));
                    $event->setCancelled(true);
                    return;
                }
                $player->setSnowball(true);
                $this->plugin->getScheduler()->scheduleRepeatingTask(new SnowballTask($player), 20);
            }
        }
    }

    /**
     * @param ProjectileHitEvent $event
     * @return void
     */
    public function onProjectileHitEvent(ProjectileHitEvent $event) : void {
        $projectile = $event->getEntity();
		if($projectile instanceof Snowball){
			$sender = $projectile->getOwningEntity();
			if($sender instanceof Player and $event instanceof ProjectileHitEntityEvent){
				if($sender->getInventory()->getItemInHand()->getCustomName() === TE::GOLD."SnowBall"){
					$player = $event->getEntityHit();
					if($player instanceof Player){
						$this->projectile[$sender->getName()] = [$player->x, $player->y, $player->z];
						if(isset($this->projectile[$sender->getName()])){
							$player->teleport($sender->getPosition());
							$sender->teleport(new Vector3($this->projectile[$sender->getName()][0], $this->projectile[$sender->getName()][1], $this->projectile[$sender->getName()][2]));
							unset($this->projectile[$sender->getName()]);
						}
					}
				}
			}
        }
        if($projectile instanceof Egg){
			$sender = $projectile->getOwningEntity();
			if($sender instanceof Player and $event instanceof ProjectileHitEntityEvent and $sender->hasPermission("use.egg.item")){
				$player = $event->getEntityHit();
				if($player instanceof Player){
					if(!Factions::isSpawnRegion($sender) && !Factions::isSpawnRegion($player) && Factions::getFaction($sender->getName()) !== Factions::getFaction($player->getName())){
						if($player->getName() === $sender->getName()){
							return;
						}
						$sender->sendMessage(TE::BOLD.TE::GOLD."Egg".TE::RESET.TE::WHITE.": ".TE::GRAY."you marked the player ".TE::BOLD.TE::GREEN.$player->getName());
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), 20 * 5, 0));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 20 * 5, 0));
					}
				}
			}
		}
    }
}

?>