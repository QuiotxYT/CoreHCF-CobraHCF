<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use VitalHCF\API\InvMenu\ChestInventory;

use VitalHCF\item\netherite\{Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe};
use VitalHCF\item\specials\{StormBreaker, AntiTrapper, NinjaShear};

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\block\{Block, BlockIds};
use pocketmine\block\Chest;
use pocketmine\event\Listener; 
use pocketmine\math\Vector3;

use pocketmine\item\{ItemFactory, Item, ItemIds};
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\event\player\{PlayerJoinEvent, PlayerInteractEvent};
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\entity\EntityLevelChangeEvent;

class Crates implements Listener {
	
	const MYTHIC_CRATE = "Mythic", XTREME_CRATE = "Xtreme", COSMIC_CRATE = "Cosmic", NETHERITE_CRATE = "Netherite";
	
	/** @var Loader */
	protected $plugin;

	/** @var Array[] */
	protected static $cratesConfig = [], $cratesData = [], $cratesManager = [];
	
	/** @var Array[] */
	protected static $particles = [];
	
	/**
	 * Crates Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
		//TODO:
		self::$cratesManager = (new Config($plugin->getDataFolder()."CratesConfig.yml", Config::YAML))->getAll();
		self::$cratesConfig = new Config($plugin->getDataFolder()."CratesManager.yml", Config::YAML);
		foreach(self::$cratesConfig->get("Crates") as $type => $values){
			self::$cratesData[$type] = $values;
		}
	} 

	/**
     * @param PlayerJoinEvent $event
     * @return void
     */
	public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
		self::addParticlesFloating($event->getPlayer());
	}
	
	/**
     * @param PlayerInteractEvent $event
     * @return void
     */
	public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		if(Factions::isSpawnRegion($event->getBlock()) and $event->getBlock() instanceof Chest and self::isCrate($event->getBlock())){
			self::openCrate($player, $event->getBlock());
			$event->setCancelled(true);
		}
	}

	/**
     * @param BlockBreakEvent $event
     * @return void
     */
	public function onBlockBreak(BlockBreakEvent $event) : void {
		$player = $event->getPlayer();
		$config = new Config($this->plugin->getDataFolder()."CratesConfig.yml", Config::YAML);
		if(Factions::isSpawnRegion($event->getBlock()) and $event->getBlock() instanceof Chest and self::isCrate($event->getBlock()) and $player->isOp()){
			unset(self::$cratesManager[self::getCrateType($event->getBlock())]);
			$config->remove(self::getCrateType($event->getBlock()));
			$config->save();
			$player->sendMessage(TE::GREEN."UnRegister correctly the Crate: ".TE::RESET.self::getCrateName(self::getCrateType($event->getBlock())));
		}
	}

	/**
     * @param BlockPlaceEvent $event
     * @return void
     */
	public function onBlockPlace(BlockPlaceEvent $event) : void {
		$player = $event->getPlayer();
		$config = new Config($this->plugin->getDataFolder()."CratesConfig.yml", Config::YAML);
		if(Factions::isSpawnRegion($event->getBlock()) and $event->getBlock() instanceof Chest and self::isCrate($event->getBlock()) and $player->isOp()){
			self::$cratesManager[self::getCrateType($event->getBlock())] = ["CrateName" => self::getCrateName(self::getCrateType($event->getBlock())), "Vector3" => [$event->getBlock()->getX(), $event->getBlock()->getY(), $event->getBlock()->getZ()]];
			$config->setAll(self::$cratesManager);
			$config->save();
			$player->sendMessage(TE::GREEN."Register correctly the Crate: ".TE::RESET.self::getCrateName(self::getCrateType($event->getBlock())));
		}
	}

	/**
     * @param EntityLevelChangeEvent $event
     * @return void
     */
	public function onChangeLevelEvent(EntityLevelChangeEvent $event) : void {
		$player = $event->getEntity();
		$levelOrigin = $event->getOrigin();
		$level = $event->getTarget();
		foreach(self::getTextParticles() as $particle){
			if($particle instanceof FloatingTextParticle){
				if($level->getName() === $this->plugin->getServer()->getDefaultLevel()->getName()){
					$particle->setInvisible(false);
					$level->addParticle($particle, [$player]);
				}else{
					$particle->setInvisible(true);
					$levelOrigin->addParticle($particle, [$player]);
				}
			}
		}
	}

	/**
	 * @return Array[]
	 */
	public static function getTextParticles() : ?Array {
		return self::$particles;
	}

	/**
	 * @return Array[]
	 */
	public static function getCratesAvailable(){
		return array_keys(self::$cratesData);
	}
	
	/**
	 * @param String $type
	 * @return String|null
	 */
	public static function getCrateName(String $type) : ?String {
		return str_replace("&", "§", self::$cratesData[$type]["name"]) ? str_replace("&", "§", self::$cratesData[$type]["name"]) : null;
	}
	
	/**
	 * @param String $type
	 * @return String|null
	 */
	public static function getKeyName(String $type) : ?String {
		return str_replace("&", "§", self::$cratesData[$type]["key_name"]) ? str_replace("&", "§", self::$cratesData[$type]["key_name"]) : null;
	}
	
	/**
	 * @param String $type
	 * @return String|null
	 */
	public static function getBlockId(String $type) : ?String {
		return self::$cratesData[$type]["block_id"] ? self::$cratesData[$type]["block_id"] : null;
	}

	/**
	 * @param String $type
	 * @return Array[]
	 */
	public static function getRandReward(String $type) : ?Array {
		$items = self::getCrateReward($type);
		$item1 = $items[array_rand($items)];
		$item2 = $items[array_rand($items)];
		if($type === self::MYTHIC_CRATE){
			return [$item1, $item2];
		}
		if($type === self::XTREME_CRATE){
			return [$item1];
		}
		if($type === self::COSMIC_CRATE){
			return [$item1, $item2];
		}
        if($type === self::NETHERITE_CRATE){
            return [$item1];
        }
	}

	/**
	 * @param String $type
	 * @param bool $key
	 * @return Array[]
	 */
	public static function getCrateReward(String $type, bool $key = false) : ?Array{
		if(!$key){ 
			if($type === self::XTREME_CRATE){

				$snowball = Item::get(ItemIds::SNOWBALL, 0, 2);
	            $snowball->setCustomName(TE::GOLD."SnowBall");
	            $snowball->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 0));
                $snowball->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);

	            
	            $stormbreaker = new StormBreaker();
	
	            $antiTrapper = new AntiTrapper();

                $resistance = Item::get(ItemIds::IRON_INGOT , 0, 1);
                $resistance->setCustomName(TE::BOLD . "§fResistance 2");
                $resistance->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);
                $resistance->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 1));
	            
	            $strength = Item::get(ItemIds::BLAZE_ROD , 0, 1);
	            $strength->setCustomName(TE::BOLD . "§6Strength 2");
                $strength->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);
	            $strength->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 1));

				if(self::getPercentage()){
					return [$snowball, $stormbreaker, $antiTrapper, $resistance, $strength];
				}else{
	                return [$snowball];
				}
				return null;
			}
			if($type === self::NETHERITE_CRATE){
				$sword = new Sword();
				$sword->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = new Pickaxe();
				$pickaxe->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SILK_TOUCH), 1));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				
				$helmet = new Helmet();
	    	    $chestplate = new Chestplate();
	     	   $leggings = new Leggings();
	   	     $boots = new Boots();
	   	
	   		 $helmet->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Helmet");
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	   		 
				$chestplate->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$leggings->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$boots->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 4));
				if(self::getPercentage()){
					return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots];
				}else{
					return [Item::get(ItemIds::ENDER_PEARL, 0, 4), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::EMERALD_BLOCK, 0, 32), Item::get(ItemIds::IRON_BLOCK, 0, 32), Item::get(ItemIds::GOLD_BLOCK, 0, 32), Item::get(ItemIds::GOLDEN_APPLE, 0, 16), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::APPLEENCHANTED, 0, 2)];
				}
				return null;
			}
			if($type === self::MYTHIC_CRATE){
				$sword = Item::get(ItemIds::DIAMOND_SWORD, 0, 1);
				$sword->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = Item::get(ItemIds::DIAMOND_PICKAXE, 0, 1);
				$pickaxe->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SILK_TOUCH), 1));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	
				$bow = Item::get(ItemIds::BOW, 0, 1);
				$bow->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Bow");
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 3));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::INFINITY), 2));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 3));
				
				$helmet = Item::get(ItemIds::DIAMOND_HELMET, 0, 1);
	    	    $chestplate = Item::get(ItemIds::DIAMOND_CHESTPLATE, 0, 1);
	     	   $leggings = Item::get(ItemIds::DIAMOND_LEGGINGS, 0, 1);
	   	     $boots = Item::get(ItemIds::DIAMOND_BOOTS, 0, 1);
	   	
	   		 $helmet->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Helmet");
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
	   		 $helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	   		 
				$chestplate->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$leggings->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$boots->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 4));
				if(self::getPercentage()){
					return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots, $bow];
				}else{
					return [Item::get(ItemIds::ENDER_PEARL, 0, 4), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::EMERALD_BLOCK, 0, 32), Item::get(ItemIds::IRON_BLOCK, 0, 32), Item::get(ItemIds::GOLD_BLOCK, 0, 32), Item::get(ItemIds::GOLDEN_APPLE, 0, 16), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::APPLEENCHANTED, 0, 2)];
				}
				return null;
			}
			if($type === self::COSMIC_CRATE){
				$sword = Item::get(ItemIds::DIAMOND_SWORD, 0, 1);
				$sword->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = Item::get(ItemIds::DIAMOND_PICKAXE, 0, 1);
				$pickaxe->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 3));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				
				$bow = Item::get(ItemIds::BOW, 0, 1);
				$bow->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Bow");
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 3));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::INFINITY), 2));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 3));
				
				$helmet = Item::get(ItemIds::DIAMOND_HELMET, 0, 1);
	    	    $chestplate = Item::get(ItemIds::DIAMOND_CHESTPLATE, 0, 1);
	     	   $leggings = Item::get(ItemIds::DIAMOND_LEGGINGS, 0, 1);
	   	     $boots = Item::get(ItemIds::DIAMOND_BOOTS, 0, 1);
	   	
				$helmet->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Helmet");
				$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
				
				$chestplate->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
			
				$leggings->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
			
				$boots->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 2));
				if(self::getPercentage()){
					return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots, $bow];
				}else{
					return [Item::get(ItemIds::DIAMOND_BLOCK, 0, 16), Item::get(ItemIds::EMERALD_BLOCK, 0, 16), Item::get(ItemIds::IRON_BLOCK, 0, 16), Item::get(ItemIds::GOLD_BLOCK, 0, 16), Item::get(ItemIds::GOLDEN_APPLE, 0, 6), Item::get(ItemIds::DIAMOND_BLOCK, 0, 16), Item::get(ItemIds::ARROW, 0, 1)];
				}
				return null;
			}
		}else{
			if($type === self::XTREME_CRATE){
                $snowball = Item::get(ItemIds::SNOWBALL, 0, 2);
                $snowball->setCustomName(TE::GOLD."SnowBall");
                $snowball->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 0));
                $snowball->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);

                $stormbreaker = new StormBreaker();

                $antiTrapper = new AntiTrapper();

                $resistance = Item::get(ItemIds::IRON_INGOT , 0, 1);
                $resistance->setCustomName(TE::BOLD . "Resistance Portable");
                $resistance->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);
                $resistance->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 1));

                $strength = Item::get(ItemIds::BLAZE_POWDER , 0, 1);
                $strength->setCustomName(TE::BOLD . "Strength Portable");
                $strength->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);
                $strength->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 1));

                $refill = Item::get(ItemIds::NETHER_STAR, 0, 1);
				$refill->setCustomName(TE::BOLD . "Refill");
				$refill->setLore([TE::LIGHT_PURPLE ."§aEspecial §eItems"]);

				return [$snowball, $stormbreaker, $antiTrapper, $resistance, $strength, $refill];
			}
			if($type === self::NETHERITE_CRATE){
				$sword = new Sword();
				$sword->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = new Pickaxe();
				$pickaxe->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SILK_TOUCH), 1));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				
				$helmet = new Helmet();
	    	    $chestplate = new Chestplate();
	     	   $leggings = new Leggings();
	   	     $boots = new Boots();
	   	
	   		 $helmet->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Helmet");
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	   		 
				$chestplate->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$leggings->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$boots->setCustomName(TE::GOLD.TE::BOLD."Netherite ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 4));
				return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots, Item::get(ItemIds::ENDER_PEARL, 0, 4), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::EMERALD_BLOCK, 0, 32), Item::get(ItemIds::IRON_BLOCK, 0, 32), Item::get(ItemIds::GOLD_BLOCK, 0, 32), Item::get(ItemIds::GOLDEN_APPLE, 0, 16), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::APPLEENCHANTED, 0, 2)];
			}
			if($type === self::MYTHIC_CRATE){
				$sword = Item::get(ItemIds::DIAMOND_SWORD, 0, 1);
				$sword->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = Item::get(ItemIds::DIAMOND_PICKAXE, 0, 1);
				$pickaxe->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 5));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SILK_TOUCH), 1));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	
				$bow = Item::get(ItemIds::BOW, 0, 1);
				$bow->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Bow");
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 3));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::INFINITY), 2));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 3));
				
				$helmet = Item::get(ItemIds::DIAMOND_HELMET, 0, 1);
	    	    $chestplate = Item::get(ItemIds::DIAMOND_CHESTPLATE, 0, 1);
	     	   $leggings = Item::get(ItemIds::DIAMOND_LEGGINGS, 0, 1);
	   	     $boots = Item::get(ItemIds::DIAMOND_BOOTS, 0, 1);
	   	
	   		 $helmet->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Helmet");
	   	 	$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
	   		 $helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
	   		 
				$chestplate->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$leggings->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
			
				$boots->setCustomName(TE::LIGHT_PURPLE.TE::BOLD."Mythic ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 4));
				return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots, $bow, Item::get(ItemIds::ENDER_PEARL, 0, 4), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::EMERALD_BLOCK, 0, 32), Item::get(ItemIds::IRON_BLOCK, 0, 32), Item::get(ItemIds::GOLD_BLOCK, 0, 32), Item::get(ItemIds::GOLDEN_APPLE, 0, 16), Item::get(ItemIds::DIAMOND_BLOCK, 0, 32), Item::get(ItemIds::APPLEENCHANTED, 0, 2)];
			}
			if($type === self::COSMIC_CRATE){
				$sword = Item::get(ItemIds::DIAMOND_SWORD, 0, 1);
				$sword->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Sword");
				$sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 2));
				
				$pickaxe = Item::get(ItemIds::DIAMOND_PICKAXE, 0, 1);
				$pickaxe->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Pickaxe");
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::EFFICIENCY), 3));
				$pickaxe->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
				
				$bow = Item::get(ItemIds::BOW, 0, 1);
				$bow->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Bow");
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::POWER), 3));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::INFINITY), 2));
				$bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FLAME), 3));
				
				$helmet = Item::get(ItemIds::DIAMOND_HELMET, 0, 1);
	    	    $chestplate = Item::get(ItemIds::DIAMOND_CHESTPLATE, 0, 1);
	     	   $leggings = Item::get(ItemIds::DIAMOND_LEGGINGS, 0, 1);
	   	     $boots = Item::get(ItemIds::DIAMOND_BOOTS, 0, 1);
	   	
				$helmet->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Helmet");
				$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
				
				$chestplate->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Chestplate");
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
			
				$leggings->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Leggings");
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
			
				$boots->setCustomName(TE::AQUA.TE::BOLD."Cosmic ".TE::RESET.TE::GRAY."Boots");
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 2));
				$boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::FEATHER_FALLING), 2));
				return [$sword, $pickaxe, $helmet, $chestplate, $leggings, $boots, $bow, Item::get(ItemIds::DIAMOND_BLOCK, 0, 16), Item::get(ItemIds::EMERALD_BLOCK, 0, 16), Item::get(ItemIds::IRON_BLOCK, 0, 16), Item::get(ItemIds::GOLD_BLOCK, 0, 16), Item::get(ItemIds::GOLDEN_APPLE, 0, 6), Item::get(ItemIds::DIAMOND_BLOCK, 0, 16), Item::get(ItemIds::ARROW, 0, 1)];
			}
			return [];
		}
		return [];
	}

	/**
	 * @param Player $player
	 * @param Vector3 $Vector3
	 */
	public static function openCrate(Player $player, Vector3 $Vector3){
		if(self::isCrate($Vector3)){
			$crateType = self::getCrateType($Vector3);
			$crateName = self::getCrateName($crateType);
			$crateKey = self::getKeyName($crateType);
			
			$crateBlockId = self::getBlockId($crateType);
			if($player->getInventory()->getItemInHand()->getCustomName() !== $crateKey){
				self::showReward($player, $crateType);
				return;
			}
			$items = self::getRandReward($crateType);
			foreach($items as $item){
				if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
					$player->sendMessage(TE::RED."Your inventory is full!");
					return;
				}
				$player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->setCount($player->getInventory()->getItemInHand()->getCount() - 1));
				$player->getInventory()->addItem($item);
				$player->sendMessage(TE::GOLD."You received an item ".$item->getName());
			}
		}
	}
			
	/**
	 * @param Vector3 $Vector3
	 * @return bool
	 */
	public static function isCrate(Vector3 $Vector3) : bool {
		$blockArt = Loader::getInstance()->getServer()->getDefaultLevel()->getBlockIdAt($Vector3->getX(), $Vector3->getY() - 1, $Vector3->getZ());
		if($blockArt === BlockIds::PLANKS||$blockArt === BlockIds::COBBLESTONE||$blockArt === BlockIds::QUARTZ_BLOCK||$blockArt === BlockIds::STONE_BRICK){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * @param Vector3 $Vector3
	 * @return BlockIds
	 */
	public static function getCrateType(Vector3 $Vector3){
		$blockArt = Loader::getInstance()->getServer()->getDefaultLevel()->getBlockIdAt($Vector3->getX(), $Vector3->getY() - 1, $Vector3->getZ());
		if($blockArt === BlockIds::PLANKS){
			return self::MYTHIC_CRATE;
		}
		if($blockArt === BlockIds::COBBLESTONE){
			return self::XTREME_CRATE;
		}
		if($blockArt === BlockIds::QUARTZ_BLOCK){
			return self::COSMIC_CRATE;
		}
        if($blockArt === BlockIds::STONE_BRICK){
            return self::NETHERITE_CRATE;
        }
		return null;
	}
	
	/**
	 * @param Player $player
	 * @param String $type
	 * @param Int $count
	 */
	public static function giveKey(Player $player, String $type, Int $count, String $spawned = "CONSOLE"){
		$crateKeyName = self::getKeyName($type);
		$key = Item::get(ItemIds::TRIPWIRE_HOOK, 0, $count);
		$key->setCustomName($crateKeyName);
		$player->getInventory()->addItem($key); 
		$player->sendMessage(TE::GOLD."You received the key {$crateKeyName}");
	} 
	
	/**
	 * @return void
	 */
	public static function updateTag() : void {
		foreach(self::getCratesAvailable() as $type){
			$config = self::$cratesManager[$type];
			$x = $config["Vector3"][0];
			$y = $config["Vector3"][1];
			$z = $config["Vector3"][2];
			$crateName = $config["CrateName"];
			if(!empty($x) and !empty($y) and !empty($z)){
				$Vector3 = new Vector3($x + 0.5, $y + 1, $z + 0.5);
				self::$particles[$type] = new FloatingTextParticle($Vector3, "", $crateName."\n".TE::WHITE."Tap with the indicated key to get the rewards".TE::RESET."\n".TE::WHITE."Break the chest to see the rewards");
			}
		}
	}
	
	/**
	 * @param Player $player
	 */
	public static function addParticlesFloating(Player $player){
		if(isset(self::$particles)){
			$particles = array_values(self::$particles);
			foreach($particles as $text){
				if($text instanceof FloatingTextParticle){
					foreach($text->encode() as $proxy){
						$text->setInvisible(false);
						$player->dataPacket($proxy);
					}
				}
			}
		}
	}
	
	/**
	 * @param Player $player
	 * @param String $type
	 */
	public static function showReward(Player $player, String $type){
		$inventory = new ChestInventory();
		$inventory->setName(self::getCrateName($type));
		$inventory->setContents(self::getCrateReward($type, true));
		$inventory->openInventory($player);
	}

	/**
	 * @return bool
	 */
	public static function getPercentage() : bool {
		$percentage = rand(1, 25);
		if($percentage === 5 or $percentage === 2 or $percentage === 1 or $percentage === 10 or $percentage === 15 or $percentage === 19 or $percentage === 25 or $percentage === 4 or $percentage === 10 or $percentage === 16 or $percentage === 23){
			return true;
		}else{
			return false;
		}
		return false;
	}
}

?>