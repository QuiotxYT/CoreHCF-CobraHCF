<?php

namespace VitalHCF\listeners\interact;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\Task\{GappleTask, GoldenGappleTask};

use VitalHCF\item\{GoldenApple, GoldenAppleEnchanted};

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\item\ItemIds;

use pocketmine\event\player\PlayerItemConsumeEvent;

class Gapple implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Gapple Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
		Loader::$appleenchanted = (new Config($plugin->getDataFolder()."cooldowns.yml", Config::YAML))->getAll();
		if(!empty(Loader::$appleenchanted)){
			foreach(Loader::$appleenchanted as $gapple => $name){
				$this->plugin->getScheduler()->scheduleRepeatingTask(new GappleTask($gapple), 20);
			}
		}
	}
	
	/**
	 * @param PlayerItemConsumeEvent $event
	 * @return void
	 */
	public function onPlayerItemConsumeEvent(PlayerItemConsumeEvent $event) : void {
		$player = $event->getPlayer();
		$item = $event->getItem();
		if($item->getId() === ItemIds::APPLEENCHANTED){
			if(self::isGappleCooldown($player->getName())){
				$player->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTime(Loader::$appleenchanted[$player->getName()]["time"])], Loader::getConfiguration("messages")->get("apple_cooldown")));
				$event->setCancelled(true);
			}else{
				self::addGappleCooldown($player->getName());
				$this->plugin->getScheduler()->scheduleRepeatingTask(new GappleTask($player->getName()), 20);
			}
		}
		if($item->getId() === ItemIds::GOLDEN_APPLE){
			if($player->isGoldenGapple()){
				$player->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getGoldenAppleTime())], Loader::getConfiguration("messages")->get("apple_cooldown")));
				$event->setCancelled(true);
				return;
			}
			$player->setGoldenApple(true);
			$this->plugin->getScheduler()->scheduleRepeatingTask(new GoldenGappleTask($player), 20);
		}
	}
	
	/**
	 * @param String $playerName|null
	 * @return void
	 */
	public static function addGappleCooldown(?String $playerName){
		if(!isset(Loader::$appleenchanted[$playerName])){
			Loader::$appleenchanted[$playerName] = ["time" => time() + (1 * 3600)];
			$config = new Config(Loader::getInstance()->getDataFolder()."cooldowns.yml", \pocketmine\utils\Config::YAML);
			$config->setAll(Loader::$appleenchanted);
			$config->save();
		}
	}
	
	/**
	 * @param PlayerClass $player
	 * @return void
	 */
	public static function removeGappleCooldown(?String $playerName){
		if(isset(Loader::$appleenchanted[$playerName])){
			$config = new Config(Loader::getInstance()->getDataFolder()."cooldowns.yml", \pocketmine\utils\Config::YAML);
			$config->remove($playerName);
			$config->save();
			unset(Loader::$appleenchanted[$playerName]);
		}
	}
	
	/**
	 * @param String $playerName|null
	 * @return bool
	 */
	public static function isGappleCooldown(?String $playerName) : bool {
		if(isset(Loader::$appleenchanted[$playerName])){
			if(Loader::$appleenchanted[$playerName]["time"] < time()){
				self::removeGappleCooldown($playerName);
				return false;
			}else{
				return true;
			}
		}else{
			return false;
		}
		return null; //that affects if the condition is not met
	}
}