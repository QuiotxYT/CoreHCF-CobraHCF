<?php

namespace VitalHCF\block;

use VitalHCF\Loader;
use VitalHCF\entities\tiles\MonsterTileSpawner;

use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\block\{BlockIds, Block, Transparent, BlockToolType};
use pocketmine\tile\Tile;
use pocketmine\item\{Item, Tool, TieredTool};

use pocketmine\nbt\tag\{CompoundTag, IntTag, StringTag};

class MonsterSpawner extends Transparent {
	
	/** @var Int */
	protected $id = self::MONSTER_SPAWNER;
	
	/**
	 * MonsterSpawner Constructor.
	 * @param Int $meta
	 */
	public function __construct(Int $meta = 0){
		$this->meta = $meta;
	}
	
	/**
	 * @return String
	 */
	public function getName() : String {
		return "Monster Spawner";
	}
	
	/**
	 * @return Int
	 */
	public function getToolType() : Int {
		return BlockToolType::TYPE_PICKAXE;
	}
	
	/**
	 * @return Int
	 */
	public function getToolHarvestLevel() : Int {
		return TieredTool::TIER_WOODEN;
	}
	
	/**
	 * @return Array[]
	 */
	public function getDropsForCompatibleTool(Item $item) : Array {
		return [];
	}

	/**
	 * @return bool
	 */
	public function isAffectedBySilkTouch() : bool {
		return false;
	}
	
	/**
	 * @param Item $item
	 * @param Block $blockReplace
	 * @param Block $blockClicked
	 * @param Int $face
	 * @param Vector3 $clickVector
	 * @param Player $player
	 * @return bool
	 */
	public function place(Item $item, Block $blockReplace, Block $blockClicked, Int $face, Vector3 $clickVector,Player $player = null) : bool {
		$this->getLevel()->setBlock($blockReplace, $this, true, true);
		$nbt = new CompoundTag("", [
			new StringTag("id", Tile::MOB_SPAWNER),
			new StringTag("CustomName", $item->getCustomName()),
			new IntTag("x", $this->x),
			new IntTag("y", $this->y),
			new IntTag("z", $this->z),
		]);
		$tile = $this->getLevel()->getTile($this);
		if(!$tile instanceof MonsterTileSpawner){
			$tile = Tile::createTile("MonsterTileSpawner", $this->getLevel(), $nbt);
		}
		$tile->setNameNBT($item->getCustomName());
		$tile->spawnToAll();
		return true;
	}
	
	/**
	 * @return Int
	 */
	protected function getXpDropAmount() : Int {
		return mt_rand(15, 43);
	}
}

?>