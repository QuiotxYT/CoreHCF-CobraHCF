<?php

namespace VitalHCF\kit;

use VitalHCF\Loader;
use VitalHCF\player\Player;

class KitManager {
	
	/**
	 * @param String $kitName
	 * @return bool
	 */
	public static function isKit(String $kitName) : bool {
		if(isset(Loader::$kits[$kitName])){
			return true;
		}else{
			return false;
		}
		return false;
	}
	
	/**
	 * @param String $kitName
	 * @return Kit
	 */
	public static function getKit(String $kitName) : Kit {
		$kit = null;
		if(self::isKit($kitName)){
			$kit = clone Loader::$kits[$kitName];
		}
		return $kit;
	}
	
	/**
	 * @return Array[]
	 */
	public static function getKits() : Array {
		return Loader::$kits;
	}
}

?>