<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\listeners\Crates;

use pocketmine\item\{Item, ItemIds};
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class ReclaimCommand extends PluginCommand {
	
	/**
	 * ReclaimCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("reclaim", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if($sender->isOp()){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 25);
				Crates::giveKey($sender, "Cosmic", 20);
				Crates::giveKey($sender, "Xtreme", 10);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
			return;
		}
		if($sender->hasPermission("partner.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 25);
				Crates::giveKey($sender, "Cosmic", 30);
				Crates::giveKey($sender, "Xtreme", 8);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
		if($sender->hasPermission("demon.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 25);
				Crates::giveKey($sender, "Cosmic", 30);
				Crates::giveKey($sender, "Xtreme", 6);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("vitalhero.reclaim")||$sender->hasPermission("nitrobooster.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
				Crates::giveKey($sender, "Cosmic", 20);
				Crates::giveKey($sender, "Xtreme", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
		if($sender->hasPermission("vitalhero+.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 20);
				Crates::giveKey($sender, "Cosmic", 25);
				Crates::giveKey($sender, "Xtreme", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
        if($sender->hasPermission("youtuber.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 3);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("famous.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
				Crates::giveKey($sender, "Cosmic", 20);
				Crates::giveKey($sender, "Xtreme", 3);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("monster.reclaim")||$sender->hasPermission("miniyt.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 2);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
    }
}

?>