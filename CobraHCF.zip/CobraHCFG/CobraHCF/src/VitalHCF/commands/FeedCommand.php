<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\command\{PluginCommand, CommandSender};
use pocketmine\utils\{Config, TextFormat as TE};

class FeedCommand extends PluginCommand {

    /**
     * FeedCommand Constructor.
     */
    public function __construct(){
        parent::__construct("feed", Loader::getInstance());
        $this->setPermission("feed.command.use");
    }

    /**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        $sender->setFood(20);
        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_food_correctly")));
        return;
    }
}

?>