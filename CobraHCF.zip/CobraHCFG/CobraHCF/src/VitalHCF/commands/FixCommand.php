<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\Tool;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class FixCommand extends PluginCommand {
	
	/**
	 * FixCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("fix", Loader::getInstance());
		$this->setPermission("fixall.command.use");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission("fixall.command.use")){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if(count($args) === 0){
            $sender->sendMessage(
            TE::YELLOW."Use: /{$label} all ".TE::GRAY."(To repair all the items in your inventory)"."\n".
            TE::YELLOW."Use: /{$label} all <playerName> ".TE::GRAY."(To repair all other player's items)"
            );
            return;
		}
		if($args[0] == "all"){
			if($sender->hasPermission("fixallother.command.use")){
				if(!empty($args[1])){
					$player = Loader::getInstance()->getServer()->getPlayer($args[1]);
					if($player === null){
						return;
					}
					foreach($player->getInventory()->getContents() as $id => $item){
						if($item instanceof Tool or $item instanceof Armor){
							if($item->getDamage() > 0){
								$player->getInventory()->setItem($id, $item->setDamage(0));
							}
						}
					}
					foreach($player->getArmorInventory()->getContents() as $id => $item){
						if($item instanceof Tool or $item instanceof Armor){
							if($item->getDamage() > 0){
								$player->getArmorInventory()->setItem($id, $item->setDamage(0));
							}
						}
					}
					$sender->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("player_fix_other_player_correctly")));
				}else{
					if(!$sender->hasPermission("fixall.command.use")){
						$sender->sendMessage(TE::RED."You have not permissions to use this command");
						return;
					}
					foreach($sender->getInventory()->getContents() as $id => $item){
						if($item instanceof Tool or $item instanceof Armor){
							if($item->getDamage() > 0){
								$sender->getInventory()->setItem($id, $item->setDamage(0));
							}
						}
					}
					foreach($sender->getArmorInventory()->getContents() as $id => $item){
						if($item instanceof Tool or $item instanceof Armor){
							if($item->getDamage() > 0){
								$sender->getArmorInventory()->setItem($id, $item->setDamage(0));
							}
						}
					}
					$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_fix_correctly")));
				}
			}else{
				if(!$sender->hasPermission("fixall.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				foreach($sender->getInventory()->getContents() as $id => $item){
					if($item instanceof Tool or $item instanceof Armor){
						if($item->getDamage() > 0){
							$sender->getInventory()->setItem($id, $item->setDamage(0));
						}
					}
				}
				foreach($sender->getArmorInventory()->getContents() as $id => $item){
					if($item instanceof Tool or $item instanceof Armor){
						if($item->getDamage() > 0){
							$sender->getArmorInventory()->setItem($id, $item->setDamage(0));
						}
					}
				}
				$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_fix_correctly")));
			}
		}
	}
}

?>