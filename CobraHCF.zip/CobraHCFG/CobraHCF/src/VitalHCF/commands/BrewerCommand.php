<?php

namespace VitalHCF\commands;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\{Config, TextFormat as TE};

use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\tile\{Tile, Chest};
use pocketmine\level\Position;
use pocketmine\item\{Item, ItemIds};

class BrewerCommand extends PluginCommand {
	
	/**
	 * BrewerCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("brewer", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(Factions::getRegionName($sender) !== Factions::getFaction($sender->getName())){
			$sender->sendMessage(TE::RED."You can only execute this command in your claim!");
			return;
		}
		if($sender->getBrewerTime() < time()){
			$position = $sender->getPosition();
			/** TODO: 4 variables are implemented to make the combination of chests */
			$tile1 = self::createTileChest($position);
		
			$tile2 = self::createTileChest(new Position($position->x + 1, $position->y, $position->z, $position->getLevel()));
		
			$tile3 = self::createTileChest(new Position($position->x, $position->y + 1, $position->z, $position->getLevel()));
		
			$tile4 = self::createTileChest(new Position($position->x + 1, $position->y + 1, $position->z, $position->getLevel()));

			$tile5 = self::createTileChest(new Position($position->x, $position->y + 2, $position->z, $position->getLevel()));

			$tile6 = self::createTileChest(new Position($position->x + 1, $position->y + 2, $position->z, $position->getLevel()));

		
			/** @var ItemIds */
			for($x = 0; $x <= 26; ++$x){
				$tile1->getInventory()->setItem($x, Item::get(ItemIds::SPLASH_POTION, 22, 1));
				$tile2->getInventory()->setItem($x, Item::get(ItemIds::SPLASH_POTION, 22, 1));
				$tile3->getInventory()->setItem($x, Item::get(ItemIds::POTION, 16, 1));
				$tile4->getInventory()->setItem($x, Item::get(ItemIds::POTION, 13, 1));
				$tile5->getInventory()->setItem($x, Item::get(ItemIds::POTION, 8, 1));
				$tile6->getInventory()->setItem($x, Item::get(ItemIds::SPLASH_POTION, 22, 1));

			}
			$sender->resetBrewerTime();
		}else{
			$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getBrewerTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
        }
	}
	
	/**
	 * @param Position $position
	 * @return bool
	 */
	private static function createTileChest(\pocketmine\level\Position $position){
		/** @var Tile Chest */
		$chest = Tile::createTile("Chest", $position->level, Chest::createNBT($position));
		/** @var Vector3 :x|:y|:z */
		$position->level->setBlock(new Vector3($chest->getX(), $chest->getY(), $chest->getZ()), Block::get(Block::CHEST));
		return $chest;
	}
}

?>