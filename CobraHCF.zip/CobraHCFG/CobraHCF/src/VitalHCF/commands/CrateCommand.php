<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\listeners\Crates;
use VitalHCF\player\Player;
use VitalHCF\crates\{Crate, CrateManager, CrateBackup};

use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{PluginCommand, CommandSender};

class CrateCommand extends PluginCommand {
	
	/**
	 * CrateCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("crates", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(count($args) === 0){
			$sender->sendMessage(TE::RED."Use: /{$label} help (view list of commands)");
			return;
        }
		if(!$sender->isOp()){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
        switch($args[0]){
        	case "updatetag":
                if(!$sender->isOp()){
                    $sender->sendMessage(TE::RED."You have not permissions to use this command");
                    return;
                }
                Crates::updateTag();
                foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $players){
                    Crates::addParticlesFloating($players);
                }
            break; 
            case "give":
                if(!$sender->isOp()){
                    $sender->sendMessage(TE::RED."You have not permissions to use this command");
                    return;
                }
                if(empty($args[1])||empty($args[2])||empty($args[3])){
                    $sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <playerName:all> <crateType> <keyAmount>");
                    return;
                }
                if(!in_array($args[2], Crates::getCratesAvailable())){
                    $sender->sendMessage(TE::RED."The key you are entering does not exist. ".TE::YELLOW."(Mega, 
                    Ability, Special, Lord)");
                    return;
                }
                if($args[1] == "all"){
                    foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $players){
                        Crates::giveKey($players, $args[2], $args[3], $sender->getName());
                    }
                    $players->sendMessage(TE::GOLD."You receive a key ".Crates::getKeyName($args[2]));
                    return;
                }
                $player = Loader::getInstance()->getServer()->getPlayer($args[1]);
                if($player === null){
                    $sender->sendMessage(TE::RED."This player is offline!");
                    return;
                }
                Crates::giveKey($player, $args[2], $args[3], $sender->getName());
                $player->sendMessage(TE::GOLD."You receive a key ".Crates::getKeyName($args[2]));
            break;
        }
	}
}

?>