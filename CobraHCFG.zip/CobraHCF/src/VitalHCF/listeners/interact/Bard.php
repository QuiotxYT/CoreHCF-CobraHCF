<?php

namespace VitalHCF\listeners\interact;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use pocketmine\event\Listener;
use pocketmine\item\{Item, ItemIds};
use pocketmine\event\player\{PlayerInteractEvent};
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};

use pocketmine\entity\{Effect, EffectInstance};

class Bard implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Bard Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		if($player->isBardClass()){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR||$event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				switch($event->getItem()->getId()){
					case ItemIds::SUGAR:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 10, 2));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 10, 2));
                            	}
                            }
                        }
					break;
					case ItemIds::IRON_INGOT:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 20 * 10, 2));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::DAMAGE_RESISTANCE), 20 * 10, 2));
                            	}
                            }
                        }
					break;
					case ItemIds::BLAZE_POWDER:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15 * 10, 1));
                            	}
                            }
                        }
					break;
					case ItemIds::GHAST_TEAR:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 15 * 10, 2));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 15 * 10, 2));
                            	}
                            }
                        }
					break;
					case ItemIds::FEATHER:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 10, 5));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 10, 5));
                            	}
                            }
                        }
					break;
					case ItemIds::DYE:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 30 * 10, 1));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 30 * 10, 1));
                            	}
                            }
                        }
					break;
					case ItemIds::MAGMA_CREAM:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 50 * 50, 1));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayer($value);
                        	    if($online instanceof Player && $online->distanceSquared($player) < 250){
                           	     $online->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 50 * 50, 1));
                            	}
                            }
                        }
					break;
					case ItemIds::SPIDER_EYE:
						if(Factions::isSpawnRegion($player)){
							$event->setCancelled(true);
							return;
						}
						if($player->getBardEnergy() < $player->getBardEnergyCost($event->getItem()->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getBardEnergyCost($event->getItem()->getId())], Loader::getConfiguration("messages")->get("player_not_enough_energy")));
							return;
						}
						foreach($this->plugin->getServer()->getOnlinePlayers() as $online){
							if($online->distanceSquared($player) < 250){
								$online->addEffect(new EffectInstance(Effect::getEffect(Effect::WITHER), 20 * 7, 1));
							}
						}
						$player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($event->getItem()->getId()));
						$event->getItem()->setCount($event->getItem()->getCount() - 1);
                        $player->getInventory()->setItemInHand($event->getItem()->getCount() > 0 ? $event->getItem() : Item::get(Item::AIR));                
					break;
				}
			}
		}
	}
}

?>