<?php

namespace VitalHCF\listeners;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\AsyncTask\SaveData;

use pocketmine\event\Listener;
use pocketmine\utils\{Config, TextFormat as TE};

use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};

class Death implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Death Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
	}
	
	/**
	 * @param PlayerDeathEvent $event
	 * @return void
	 */
	public function onPlayerDeathEvent(PlayerDeathEvent $event) : void {
		$player = $event->getPlayer();
		if($player instanceof Player){
			if($player->getLastDamageCause() instanceof EntityDamageByEntityEvent){
				$damager = $player->getLastDamageCause()->getDamager();
				if($damager instanceof Player){
					//TODO:
					$damager->addKills();
				}
				$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
				$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY."[".TE::YELLOW.$player->getKills().TE::GRAY."]".TE::GRAY."[".TE::RED.$player->getHealth().TE::GRAY."]".TE::GRAY." was killed by ".TE::RESET.TE::RED.$damager->getName().TE::GRAY."[".TE::YELLOW.$damager->getKills().TE::GRAY."]".TE::GRAY."[".TE::RED.$damager->getHealth().TE::GRAY."]".TE::YELLOW." using ".$damager->getInventory()->getItemInHand()->getName());
			}else{
				switch($player->getLastDamageCause()->getCause()){
					case EntityDamageEvent::CAUSE_FALL:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." fell from a high place!");
					break;
					case EntityDamageEvent::CAUSE_DROWNING:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." drowned!");
					break;
					case EntityDamageEvent::CAUSE_FIRE:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." died burned!");
					break;
					case EntityDamageEvent::CAUSE_FIRE_TICK:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." died burned!");
					break;
					case EntityDamageEvent::CAUSE_LAVA:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." died in lava!");
					break;
					case EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." it seems to explode!");
					break;
					case EntityDamageEvent::CAUSE_ENTITY_EXPLOSION:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." it seems to explode!");
					break;
					case EntityDamageEvent::CAUSE_SUICIDE:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." committed suicide!");
					break;
					case EntityDamageEvent::CAUSE_SUFFOCATION:
					$this->plugin->getServer()->getAsyncPool()->submitTask(new SaveData($player->getName(), $player->getInventory()->getContents(), $player->getArmorInventory()->getContents(), new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."inventory.yml", Config::YAML)));
					$event->setDeathMessage(TE::DARK_RED.$player->getName().TE::GRAY." he died suffocated!");
					break;
				}
			}
		}
	}
}

?>