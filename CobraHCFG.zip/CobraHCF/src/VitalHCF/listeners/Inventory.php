<?php

namespace VitalHCF\listeners;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\API\InvMenu\ChestInventory;

use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;

use pocketmine\event\player\{PlayerQuitEvent, PlayerInteractEvent};
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\inventory\transaction\action\SlotChangeAction;

class Inventory implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Inventory Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
	}
	
	/**
	 * @param PlayerQuitEvent $event
	 * @return void
	 */
	public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
		$player = $event->getPlayer();
		if($player->isInventoryHandler()){
			$player->unsetInventoryHandler();
		}
	}
	
	/**
	 * @param InventoryCloseEvent $event
	 * @return void
	 */
	public function onInventoryCloseEvent(InventoryCloseEvent $event) : void {
		$player = $event->getPlayer();
		$inventory = $event->getInventory();
		if($inventory instanceof ChestInventory){
			//TODO:
			$inventory->removeFakeBlock($player);
			$player->unsetInventoryHandler();
		}
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
		$item = $event->getItem();
        if(in_array($item->getId(), Loader::getDefaultConfig("items_id"))){
        	$event->setCancelled(true);
        }
	}
	
	/**
	 * @param InventoryTransactionEvent $event
	 * @return void
	 */
	public function onInventoryTransactionEvent(InventoryTransactionEvent $event) : void {
		$transaction = $event->getTransaction();
		foreach($transaction->getActions() as $action){
			if($action instanceof SlotChangeAction){
				$inventory = $action->getInventory();
				if($inventory instanceof ChestInventory){
					$event->setCancelled(true);
				}
			}
		}
	}
}

?>