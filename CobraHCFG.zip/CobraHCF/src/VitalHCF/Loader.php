<?php

namespace VitalHCF;

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\plugin\PluginBase;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;

use VitalHCF\provider\{
    SQLite3Provider, YamlProvider
};
use VItalHCF\player\{
    Player
};
use VitalHCF\API\{
    Scoreboards
};
use VitalHCF\listeners\{
	Listeners
};
use VitalHCF\Task\{
	BardTask, ArcherTask
};
use VitalHCF\Task\event\{
	FactionTask
};
use VitalHCF\entities\{
    Entitys
};
use VitalHCF\item\{
    Items
};
use VitalHCF\commands\{
    Commands
};
use VitalHCF\kit\{
    KitBackup
};
use RuntimeException;

class Loader extends PluginBase {
    
    /** @var Loader */
    protected static $instance;
    
    /** @var Array[] */
    public static $appleenchanted = [], $golden_apple = [], $kits = [], $crates = [];
    
    /** @var Array[] */
	public $permission = [];
    
    /**
     * @return void
     */
    public function onLoad() : void {
        self::$instance = $this;
    }
    
    /**
     * @return void
     */
    public function onEnable() : void {
        SQLite3Provider::init();
        YamlProvider::init();

        Listeners::init();
        Commands::init();
        Items::init();
        Entitys::init();

        Factions::init();
        KitBackup::init();

        self::getInstance()->getScheduler()->scheduleRepeatingTask(new BardTask(), 20);
        self::getInstance()->getScheduler()->scheduleRepeatingTask(new ArcherTask(), 20);
        self::getInstance()->getScheduler()->scheduleRepeatingTask(new FactionTask(), 80);
    }
    
    /**
     * @return void
     */
    public function onDisable() : void {
        //TODO:
        SQLite3Provider::disconnect();
        
        KitBackup::save();
    }

    /**
     * @return Loader
     */
    public static function getInstance() : Loader {
        return self::$instance;
    }

    /**
     * @return SQLite3Provider
     */
    public static function getProvider() : SQLite3Provider {
        return new SQLite3Provider();
    }

    /**
     * @return Scoreboards
     */
	public static function getScoreboard() : Scoreboards {
		return new Scoreboards();
    }

    /**
	 * @param Int $time
	 * @return String
	 */
	public static function getTimeToString(Int $time) : String {
		return gmdate("i:s", $time);
	}
	
	/**
	 * @param Int $time
	 * @return String
	 */
	public static function getTimeToFullString(Int $time) : String {
		return gmdate("H:i:s", $time);
	}
    
    /**
     * @param Int $time
     * @return String|null
     */
    public static function getTime(Int $time) : ?String {
		$remaning = $time - time();
		$h = $remaning % 86400;
		$m = $remaning % 3600;
		$s = $remaning % 60;
		
		$hours = floor($h / 3600);
		$minutes = floor($m / 60);
		$seconds = ceil($s);
		return $hours.":".$minutes.":".$seconds;
	}

    /**
     * @param String $configuration
     */
    public static function getDefaultConfig($configuration){
        return self::getInstance()->getConfig()->get($configuration);
    }
    
    /**
     * @param String $configuration
     */
    public static function getConfiguration($configuration){
    	return new Config(self::getInstance()->getDataFolder()."{$configuration}.yml", Config::YAML);
    }
    
    /**
     * @param String $pluginData
     */
    public static function getPluginData(String $pluginData){
    	return self::getInstance()->getServer()->getPluginManager()->getPlugin($pluginData);
    }

    /**
     * @param Player $player
     */
    public function getPermission(Player $player){
        if(!isset($this->permission[$player->getName()])){
            $this->permission[$player->getName()] = $player->addAttachment($this);
        }
        return $this->permission[$player->getName()];
    }
}

?>