<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\level\Level;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class NearCommand extends PluginCommand {

    /**
     * NearCommand Constructor.
     */
    public function __construct(){
        parent::__construct("near", Loader::getInstance());
        $this->setPermission("near.command.use");
    }
    
    /**
     * @param CommandSender $sender
     * @param String $label
     * @param Array $args
     * @return void
     */
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission("near.command.use")){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        $players = [];
        $message = null;
        $sender->sendMessage(TE::GOLD."Nearby Players: "."\n");
        foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
            if((int)$player->distance($sender) < 200){
                if($player->getName() === $sender->getName()){
                    return;
                }
                $sender->sendMessage(TE::RESET.$player->getName().TE::GRAY."(".TE::DARK_RED.(int)$player->distance($sender)."m".TE::GRAY.")"."\n");
            }
        }
    }
}

?>