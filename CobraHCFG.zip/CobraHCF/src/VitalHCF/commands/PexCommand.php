<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\provider\MysqlProvider;

use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\TextFormat as TE;

class PexCommand extends PluginCommand {
	
	protected $listRanks = ["Guest", "Owner", "Admin", "Jr-Admin", "Sr-Admin", "Mod", "Sr-Mod", "Partner", "MiniYT", "YouTuber", "Famous", "Monster", "VitalHero", "VitalHero+", "Demon", "Streamer", "Developer", "Trainee", "Co-Owner", "NitroBooster"];
	
	/**
	 * PexCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("pex", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission("pex.command.use")){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if(count($args) === 0){
			$sender->sendMessage(TE::RED."Use: /{$label} help (view list of commands)");
			return;
		}
		switch($args[0]){
			case "setrank":
				if(!$sender->hasPermission("pex.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(empty($args[1])||empty($args[2])){
					$sender->sendMessage(TE::RED."Use: /pex {$args[0]} <playerName> <rankName>");
					return;
				}
				if(!is_string($args[1])||!is_string($args[2])){
					$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_string")));
					return;
				}
				if(!in_array($args[2], $this->listRanks)){
					$sender->sendMessage(TE::RED."Rank {$args[2]} not exists!");
					return;
				}
				$connection = MysqlProvider::getDataBase()->query("SELECT * FROM players_data_ranks WHERE player_name = '$args[1]';");
				$result = $connection->fetch_array(MYSQLI_ASSOC);
				if(empty($result)){
					//TODO:
					MysqlProvider::getDataBase()->query("INSERT INTO players_data_ranks(player_name, rank_id) VALUES ('$args[1]', '$args[2]');");
				}else{
					//TODO:
					MysqlProvider::getDataBase()->query("UPDATE players_data_ranks SET rank_id = '$args[2]' WHERE player_name = '$args[1]';");
				}
				$connection->close();
			break;
			case "list":
				if(!$sender->hasPermission("pex.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(empty($args[1])){
					$sender->sendMessage(TE::RED."Use: /pex {$args[0]} <rankName>");
					return;
				}
				if(!in_array($args[1], $this->listRanks)){
					$sender->sendMessage(TE::RED."Rank {$args[1]} not exists!");
					return;
				}
				$connection = MysqlProvider::getDataBase()->query("SELECT * FROM players_data_ranks WHERE rank_id = '$args[1]';");
				while($result = $connection->fetch_array(MYSQLI_ASSOC)){
					$sender->sendMessage(TE::GREEN."List of users with rank {$args[1]} ".TE::YELLOW.$result["player_name"]);
				}
				$connection->close();
			break;
			case "help":
			case "?":
				if(!$sender->hasPermission("pex.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				$sender->sendMessage(
				TE::YELLOW."/{$label} setrank <playerName> <rankName> ".TE::GRAY."(To place a new rank on a player)"
				);
			break;
		}
	}
}

?>